<h3>WMDD- 4935</h3>

Group Member: <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Maninderjeet Singh<br>
		       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jaskaran Singh<br>
		       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jaspreet Kaur Brar<br>
		       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Harmanreet Kaur</b><br><br>

<p>We have designed and developed the word guessing game which runs on server. </p>
<p><b>There are some software’s that we have used to build this game.</b></p>
<ul>
<li>Python 3 </li>
<li>Flask </li> <br>
</ul>

<p><b>Further you need to install the library such as:</b></p>
<ul>
<li>requests</li>
<li>lxml</li> 
<li>bs4</li>
<li>Beautiful Soap</li> 
</ul>

<p><b>How the game works:</b></p>
<ul>
	<li>Python fetches movie names from imdb top 250 movies page and generates an array.</li>
	<li>One word is chosen from array </li>
	<li>Blanks are displayed according to the word generated.</li>
	<li>Html form is used to get the user input.</li>
<li>When user enters a letter, if it exists in the name it is displayed, else message is displayed that the input is wrong.</li>
	<li>When user finds the name message is displayed “you found it”.</li>
<ul>

